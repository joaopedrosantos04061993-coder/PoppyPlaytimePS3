#!/usr/bin/env bash
# Compila o EBOOT.BIN (PPU/PS3) usando o toolchain ps3dev + PSL1GHT
set -e
export PS3DEV=${PS3DEV:-/opt/ps3dev}
export PSL1GHT=${PSL1GHT:-$PS3DEV/psl1ght}
export PATH="$PS3DEV/ppu/bin:$PSL1GHT/bin:$PATH"

cd "$(dirname "$0")/.."
make clean >/dev/null 2>&1 || true
make -j"$(nproc)" 2>&1 | tail -40
ls -la poppy_ps3.elf
echo "OK: poppy_ps3.elf"
