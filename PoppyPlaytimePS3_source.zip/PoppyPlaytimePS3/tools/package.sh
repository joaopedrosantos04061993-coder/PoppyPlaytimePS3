#!/usr/bin/env bash
# Monta a arvore app_home (XMB) e gera o PKG instalavel
set -e
export PS3DEV=${PS3DEV:-/opt/ps3dev}
export PSL1GHT=${PSL1GHT:-$PS3DEV/psl1ght}
export PATH="$PS3DEV/ppu/bin:$PSL1GHT/bin:$PATH"

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
APPID="POPP00001"
CID="UP0001-${APPID}_00-0000000000000000"
TITLE="Poppy Playtime - Capitulo 1"
OUT="$ROOT/dist"
APP="$OUT/app_home"

rm -rf "$OUT"
mkdir -p "$APP/USRDIR/data"

# 1) EBOOT.BIN - ELF PPU assinado como "fake SELF" (roda em CFW/HEN)
fself "$ROOT/poppy_ps3.elf" "$APP/USRDIR/EBOOT.BIN"

# 2) PARAM.SFO - metadados que o XMB le (titulo, id, categoria HG)
sfo --title "$TITLE" --appid "$APPID" -f "$ROOT/tools/sfo.xml" "$APP/PARAM.SFO"

# 3) arte do XMB
cp "$ROOT/xmb/ICON0.PNG" "$APP/ICON0.PNG"
cp "$ROOT/xmb/PIC1.PNG"  "$APP/PIC1.PNG"

# 4) assets do jogo
cp "$ROOT/assets/menu_bg.raw"    "$APP/USRDIR/data/"
cp "$ROOT/assets/chapter_bg.raw" "$APP/USRDIR/data/"
cp "$ROOT/assets/font.raw"       "$APP/USRDIR/data/"

# 5) PKG
pkg --contentid "$CID" "$APP" "$OUT/PoppyPlaytime_Capitulo1_PS3.pkg"

echo "--- conteudo ---"
find "$APP" -type f -printf '%10s  %p\n' | sort -k2
echo "--- pkg ---"
ls -la "$OUT/PoppyPlaytime_Capitulo1_PS3.pkg"
