#!/usr/bin/env python3
"""Prepara os assets do port PS3: texturas BGRA cruas + atlas de fonte + arte do XMB."""
import os
import sys
from PIL import Image, ImageDraw, ImageFont

SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/ubuntu/upload/ext/PoppyPlaytimeUnity/Assets"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/home/ubuntu/ps3/PoppyPlaytimePS3/assets"

os.makedirs(OUT, exist_ok=True)


def to_bgra_raw(img, w, h, path):
    """PS3 RSX A8R8G8B8 espera bytes na ordem B,G,R,A (little-endian ARGB)."""
    img = img.convert("RGB").resize((w, h), Image.LANCZOS)
    b, g, r = img.split()
    a = Image.new("L", (w, h), 255)
    out = Image.merge("RGBA", (b, g, r, a))
    with open(path, "wb") as fh:
        fh.write(out.tobytes())
    print(f"{path}: {w}x{h} {os.path.getsize(path)} bytes")


# --- fundos do menu (1280x720, mesma resolucao do prototipo) ---
to_bgra_raw(Image.open(f"{SRC}/UI/MenuBackground.jpg"), 1280, 720, f"{OUT}/menu_bg.raw")
to_bgra_raw(Image.open(f"{SRC}/UI/ChapterBackground.jpg"), 1280, 720, f"{OUT}/chapter_bg.raw")

# --- atlas de fonte: 16 colunas x 6 linhas de celulas 48x48, ASCII 32..127 ---
CELL_W, CELL_H = 48, 48
COLS, ROWS = 16, 6
ATLAS_W, ATLAS_H = CELL_W * COLS, CELL_H * ROWS
atlas = Image.new("RGBA", (ATLAS_W, ATLAS_H), (255, 255, 255, 0))
draw = ImageDraw.Draw(atlas)

font = None
for candidate in (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
):
    if os.path.exists(candidate):
        font = ImageFont.truetype(candidate, 32)
        print("fonte:", candidate)
        break
if font is None:
    font = ImageFont.load_default()
    print("fonte: bitmap padrao")

for code in range(32, 128):
    idx = code - 32
    cx = (idx % COLS) * CELL_W
    cy = (idx // COLS) * CELL_H
    ch = chr(code)
    bbox = draw.textbbox((0, 0), ch, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    draw.text((cx + (CELL_W - tw) / 2 - bbox[0], cy + (CELL_H - th) / 2 - bbox[1]), ch,
              font=font, fill=(255, 255, 255, 255))

to_bgra_raw(atlas, ATLAS_W, ATLAS_H, f"{OUT}/font.raw")

# --- metadados do atlas para o codigo C ---
with open(f"{OUT}/font.h", "w") as f:
    f.write("/* gerado por prepare_assets.py */\n")
    f.write(f"#define FONT_ATLAS_W {ATLAS_W}\n#define FONT_ATLAS_H {ATLAS_H}\n")
    f.write(f"#define FONT_CELL_W {CELL_W}\n#define FONT_CELL_H {CELL_H}\n")
    f.write(f"#define FONT_COLS {COLS}\n#define FONT_ROWS {ROWS}\n")

# --- arte do XMB (PS3 exige ICON0 320x176 e PIC1 1920x1080) ---
xmb = "/home/ubuntu/ps3/PoppyPlaytimePS3/xmb"
os.makedirs(xmb, exist_ok=True)
icon = Image.open(f"{SRC}/PS3_XMB/ICON0.png").convert("RGB").resize((320, 176), Image.LANCZOS)
icon.save(f"{xmb}/ICON0.PNG", optimize=True)
pic = Image.open(f"{SRC}/PS3_XMB/PIC1.png").convert("RGB").resize((1920, 1080), Image.LANCZOS)
pic.save(f"{xmb}/PIC1.PNG", optimize=True)
print("XMB:", os.path.getsize(f"{xmb}/ICON0.PNG"), os.path.getsize(f"{xmb}/PIC1.PNG"))
