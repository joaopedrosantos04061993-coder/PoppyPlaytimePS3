#!/usr/bin/env bash
# Compila o ELF PPU do port PS3 usando ps3dev + PSL1GHT.
# O limite de jobs evita sobrecarga; o workflow externo aplica timeout.
set -Eeuo pipefail

export PS3DEV="${PS3DEV:-/opt/ps3dev}"
export PSL1GHT="${PSL1GHT:-$PS3DEV/psl1ght}"
export PATH="$PS3DEV/ppu/bin:$PSL1GHT/bin:$PS3DEV/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

: "${PS3_BUILD_JOBS:=2}"
if ! [[ "$PS3_BUILD_JOBS" =~ ^[1-9][0-9]*$ ]]; then
  echo "PS3_BUILD_JOBS deve ser um inteiro positivo" >&2
  exit 2
fi

for command_name in make ppu-gcc; do
  command -v "$command_name" >/dev/null || {
    echo "Ferramenta ausente: $command_name" >&2
    exit 2
  }
done

echo "Arquitetura: $(uname -m)"
echo "PS3DEV=$PS3DEV"
echo "PSL1GHT=$PSL1GHT"
echo "Jobs de compilação: $PS3_BUILD_JOBS"

rm -rf build poppy_ps3.elf poppy_ps3.self
mkdir -p build

# tee preserva o código de saída do make por causa de pipefail e deixa o log completo no artefato.
make -j"$PS3_BUILD_JOBS" 2>&1 | tee build/build.log

test -s poppy_ps3.elf
printf 'ELF gerado: '
stat -c '%s bytes' poppy_ps3.elf
echo "OK: poppy_ps3.elf"
